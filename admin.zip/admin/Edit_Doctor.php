<?php
include('security.php');
include('CheckLogin.php');
include('includes/header.php'); 
include('includes/navbar.php'); 


?>


         <div class="details">
            <!-- Oredr Data List -->
            <div class="recentOrders">
                <div class="cardHeader" style="display: block;">
                    <br> <br>

                    <h2 style="color:#3851a2;">Edit Doctor</h2> <br>
                        <?php  
                   
if(isset($_SESSION['status']) && $_SESSION['status'] != '' )
{
      echo '<h2 class="big-danger" style="color:#21cdc0; text-align:center;"> '.$_SESSION['status'].' </h2>';# text-white
      unset($_SESSION['status']);
  }
  ?>
                    <!-- <a href="#" class="btn">View All</a> <br> <br> <br> -->
                   
      <form action="code.php" method="post">
                        <?php 
                        $Doctor_ID = $_POST['Doctor_ID'];
                    $query = "SELECT * FROM doctor WHERE Doctor_ID=$Doctor_ID";
                     $query_run = mysqli_query($connection, $query);
                     $row = mysqli_fetch_assoc($query_run);

                            ?>
                      <br>  <div class="ptext" style="width: 1000px; padding: 20px; background-color: #21cdc0;position: relative; color: white; left: 30px;">
                        <h3>Doctor Name</h3><br>
                        <input type="text" name="E_D_Name"  value="<?php echo $row['D_Name']; ?>" style="padding:10px 375px;">
                    </div>
                        <br>
                        <div class="ptext" style="width: 1000px; padding: 20px; background-color: #21cdc0;position: relative; color: white; left: 30px;">
                        <h3>Doctor DOB</h3><br>
                        <input type="date" name="E_D_DOB"  value="<?php echo $row['D_DOB']; ?>" style="padding:10px 375px;">
                    </div>
                        <br>
                        <div class="ptext" style="width: 1000px; padding: 20px; background-color: #21cdc0;position: relative; color: white; left: 30px;">
                        <h3>Doctor Gender</h3><br>
                         <select type="text" name="E_D_Gender" value="<?php echo $row['D_Gender']; ?>" style="padding:10px 430px;">
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                        </select>
                    </div>
                        <br>
                        <div class="ptext" style="width: 1000px; padding: 20px; background-color: #21cdc0;position: relative; color: white; left: 30px;">
                        <h3>Doctor Email</h3><br>
                        <input type="email" name="E_D_Email"  value="<?php echo $row['D_Email']; ?>" style="padding:10px 375px;">
                    </div>
                        <br>
                        <div class="ptext" style="width: 1000px; padding: 20px; background-color: #21cdc0;position: relative; color: white; left: 30px;">
                        <h3>Doctor Phone</h3><br>
                        <input type="number" name="E_D_Phone"  value="<?php echo $row['D_Contact_No']; ?>" style="padding:10px 375px;">
                    </div>
                        <br>
                        <div class="ptext" style="width: 1000px; padding: 20px; background-color: #21cdc0;position: relative; color: white; left: 30px;">
                        <h3>Doctor Address</h3><br>
                        <input type="text" name="E_D_Address"  value="<?php echo $row['D_Address']; ?>" style="padding:10px 375px;">
                    </div>
                        <br>
                        <div class="ptext" style="width: 1000px; padding: 20px; background-color: #21cdc0;position: relative; color: white; left: 30px;">
                        <h3>Doctor Speciality</h3><br>
                        <input type="text" name="E_D_Speciality"  value="<?php echo $row['D_Speciality']; ?>" style="padding:10px 375px;">
                    </div>
                        <br>
                        <div class="ptext" style="width: 1000px; padding: 20px; background-color: #21cdc0;position: relative; color: white; left: 30px;">
                        <h3>Doctor Timing</h3><br>
                        <input type="text" name="E_D_Timing"  value="<?php echo $row['D_Timing']; ?>" style="padding:10px 375px;">
                    </div>
                        <br>
                        <div class="ptext" style="width: 1000px; padding: 20px; background-color: #21cdc0;position: relative; color: white; left: 30px;">
                        <h3>Doctor Shift</h3><br>
                        <input type="text" name="E_D_Shift"  value="<?php echo $row['D_Shift']; ?>" style="padding:10px 375px;">
                    </div>
                        <br>
                        <div class="ptext" style="width: 1000px; padding: 20px; background-color: #21cdc0;position: relative; color: white; left: 30px;">
                        <h3>Doctor Shift</h3><br>
                        <input type="text" name="E_D_Password"  value="<?php echo $row['Password']; ?>" style="padding:10px 375px;">
                    </div>
                        <br>
                        <input type="hidden" name="Doctor_ID" value="<?php echo $row['Doctor_ID']; ?>">
                        <div class="buttons" style="margin: 0 auto; width: 150px;">
                    <button style="background-color: rgb(56, 81, 162); color: white; padding: 10px 40px; border: none;cursor: pointer; border-radius: 5px;" name="D_Edit_btn" type="submit">Edit</button>
                    
                 </div>

                        
                 </form>

                        <?php




                         ?>
                </div>
              




<?php 
include('includes/scripts.php'); 
include('includes/footer.php'); 
?>