<?php 
include('security.php');
include('includes/patient.php'); 


if(isset($_POST['Form_btn']))
{

    $P_Name = $_POST['P_Name'];
    $P_DOB = $_POST['P_DOB'];
    $P_Gender = $_POST['P_Gender'];
    $P_Phone = $_POST['P_Phone'];
    $P_Email = $_POST['P_Email'];
    $P_Symptoms = $_POST['P_Symptoms'];
    $P_Diagnosis = $_POST['P_Diagnosis'];
    $P_Prescription = $_POST['P_Prescription'];
    $Fees = 1000;


    $query = "INSERT INTO patient (P_Name,P_DOB,P_Gender,P_Phone,P_Email,P_Image) VALUES 
    ('$P_Name','$P_DOB','$P_Gender','$P_Phone','$P_Email','$Patient_Image')";
    $query_run = mysqli_query($connection, $query);

     $query1 = "SELECT * FROM patient";
    $query_run1 = mysqli_query($connection, $query1);

     if(mysqli_num_rows($query_run1) > 0){
                while($row = mysqli_fetch_assoc($query_run1)){
                    $Patient_ID = $row['Patient_ID'];

                }}

$date = date("Y/m/d");

    $query2 = "INSERT INTO medicalhistory (Patient_ID,Symptoms,Diagnosis,Medical_Prescription,Date,Enter_Time,Exit_Time,Fees) VALUES 
    ('$Patient_ID','$P_Symptoms','$P_Diagnosis','$P_Prescription','$date','$Enter_Time','$Enter_Time','$Fees')";
    $query_run2 = mysqli_query($connection, $query2);




 $query3 = "INSERT INTO invoice (Image,P_Name,Fees,Medical_Prescription,Symptoms,Patient_ID,Date) VALUES 
    ('$Patient_Image','$P_Name','$Fees','$P_Prescription','$P_Symptoms','$Patient_ID','$date')";
    $query_run3 = mysqli_query($connection, $query3);



$query4 = "INSERT INTO search (P_Name,P_DOB,P_Gender,P_Phone,P_Email,P_Image,Symptoms,Diagnosis,MP,Date,Enter_Time,Exit_Time) VALUES 
    ('$P_Name','$P_DOB','$P_Gender','$P_Phone','$P_Email','$Patient_Image','$P_Symptoms','$P_Diagnosis','$P_Prescription','$date','$Enter_Time','$Enter_Time')";
    $query_run4 = mysqli_query($connection, $query4);


    if($query_run2)
    {
        $_SESSION['status'] = "Patient Record Saved";
        $_SESSION['status_code'] = "success";
        header('Location: Invoice.php'); 
    }
    else
    {
        $_SESSION['status'] = "Patient Record Is Not Saved";
        $_SESSION['status_code'] = "error";
        header('Location: index.php');  
    }
}


// ----------------------------------------------------------------------------------------------------------



if(isset($_POST['Add_btn']))
{

    $D_Name = $_POST['D_Name'];
    $D_DOB = $_POST['D_DOB'];
    $D_Gender = $_POST['D_Gender'];
    $D_Email = $_POST['D_Email'];
    $D_Phone = $_POST['D_Phone'];
    $D_Address = $_POST['D_Address'];
    $D_Speciality = $_POST['D_Speciality'];
    $D_Timing = $_POST['D_Timing'];
    $D_Shift = $_POST['D_Shift'];
    $D_Password = $_POST['D_Password'];



    $query = "INSERT INTO doctor (D_Name,D_DOB,D_Gender,D_Email,D_Contact_No,D_Address,D_Speciality,D_Timing,D_Shift,Password) VALUES 
    ('$D_Name','$D_DOB','$D_Gender','$D_Email','$D_Phone','$D_Address','$D_Speciality','$D_Timing','$D_Shift','$D_Password')";
    $query_run = mysqli_query($connection, $query);

    if($query_run)
    {
        $_SESSION['status'] = "Doctor Profile Added Successfully !";
        $_SESSION['status_code'] = "success";
        header('Location: Add_Doctor.php'); 
    }
    else
    {
        $_SESSION['status'] = "Doctor Profile Is Not Added !";
        $_SESSION['status_code'] = "error";
        header('Location: Add_Doctor.php');  
    }
}




// ----------------------------------------------------------------------------------------------------------



if(isset($_POST['delete_doctor_btn']))
{

    $Doctor_ID = $_POST['Doctor_ID'];




    $query = "DELETE FROM doctor WHERE Doctor_ID=$Doctor_ID";
    $query_run = mysqli_query($connection, $query);

    if($query_run)
    {
        $_SESSION['status'] = "Doctor Profile Deleted Successfully !";
        $_SESSION['status_code'] = "success";
        header('Location: Doctors.php'); 
    }
    else
    {
        $_SESSION['status'] = "Doctor Profile Is Not Deleted !";
        $_SESSION['status_code'] = "error";
        header('Location: Doctors.php');  
    }
}



// ----------------------------------------------------------------------------------------------------------



if(isset($_POST['D_Edit_btn']))
{

    $Doctor_ID = $_POST['Doctor_ID'];
    $E_D_Name = $_POST['E_D_Name'];
    $E_D_DOB = $_POST['E_D_DOB'];
    $E_D_Gender = $_POST['E_D_Gender'];
    $E_D_Email = $_POST['E_D_Email'];
    $E_D_Phone = $_POST['E_D_Phone'];
    $E_D_Address = $_POST['E_D_Address'];
    $E_D_Speciality = $_POST['E_D_Speciality'];
    $E_D_Timing = $_POST['E_D_Timing'];
    $E_D_Shift = $_POST['E_D_Shift'];
    $E_D_Password = $_POST['E_D_Password'];


$query = "UPDATE doctor SET D_Name='$E_D_Name',
        D_DOB='$E_D_DOB',
        D_Gender='$E_D_Gender',
        D_Email='$E_D_Email',
        D_Contact_No='$E_D_Phone',
        D_Address='$E_D_Address',
        D_Speciality='$E_D_Speciality',
        D_Timing='$E_D_Timing',
        D_Shift='$E_D_Shift',
        Password='$E_D_Password'  WHERE Doctor_ID='$Doctor_ID' ";
        $query_run = mysqli_query($connection, $query);


    if($query_run)
    {
        $_SESSION['status'] = "Doctor Profile Edit Successfully !";
        $_SESSION['status_code'] = "success";
        header('Location: Doctors.php'); 
    }
    else
    {
        $_SESSION['status'] = "Doctor Profile Is Not Edit !";
        $_SESSION['status_code'] = "error";
        header('Location: Doctors.php');  
    }
}


// ----------------------------------------------------------------------------------------------------------


if(isset($_POST['delete_appointment_btn']))
{

    $Appointment_ID = $_POST['Appointment_ID'];




    $query = "DELETE FROM appointment WHERE Appointment_ID=$Appointment_ID";
    $query_run = mysqli_query($connection, $query);

    if($query_run)
    {
        $_SESSION['status'] = "Patient Appointment Deleted Successfully !";
        $_SESSION['status_code'] = "success";
        header('Location: Appointment.php'); 
    }
    else
    {
        $_SESSION['status'] = "Patient Appointment Is Not Deleted !";
        $_SESSION['status_code'] = "error";
        header('Location: Appointment.php');  
    }
}


// ----------------------------------------------------------------------------------------------------------



if(isset($_POST['delete_message_btn']))
{

    $Contact_ID = $_POST['Contact_ID'];




    $query = "DELETE FROM contact WHERE Contact_ID=$Contact_ID";
    $query_run = mysqli_query($connection, $query);

    if($query_run)
    {
        $_SESSION['status'] = "User Message Deleted Successfully !";
        $_SESSION['status_code'] = "success";
        header('Location: Message.php'); 
    }
    else
    {
        $_SESSION['status'] = "User Message Is Not Deleted !";
        $_SESSION['status_code'] = "error";
        header('Location: Message.php');  
    }
}


// ----------------------------------------------------------------------------------------------------------



if(isset($_POST['Appoitment_Edit_btn']))
{

    $Appointment_ID = $_POST['Appointment_ID'];
    $E_P_Name = $_POST['E_P_Name'];
    $E_P_DOB = $_POST['E_P_DOB'];
    $E_P_Gender = $_POST['E_P_Gender'];
    $E_P_Phone = $_POST['E_P_Phone'];
    $E_P_Email = $_POST['E_P_Email'];
  

        $query = "UPDATE appointment SET P_Name='$E_P_Name',
        P_DOB='$E_P_DOB',
        P_Gender='$E_P_Gender',
        P_Phone='$E_P_Phone',
        P_Email='$E_P_Email'  WHERE Appointment_ID='$Appointment_ID' ";
        $query_run = mysqli_query($connection, $query);


    if($query_run)
    {
        $_SESSION['status'] = "Patient Appointment Edit Successfully !";
        $_SESSION['status_code'] = "success";
        header('Location: Appointment.php'); 
    }
    else
    {
        $_SESSION['status'] = "Patient Appointment Is Not Edit !";
        $_SESSION['status_code'] = "error";
        header('Location: Appointment.php');  
    }
}


// ----------------------------------------------------------------------------------------------------------
// ----------------------------------------------------------------------------------------------------------

// ----------------------------------------------------------------------------------------------------------

// ----------------------------------------------------------------------------------------------------------

?>