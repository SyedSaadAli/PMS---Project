<?php
if(isset($_SESSION['Email']) AND $_SESSION['Email'] === "admin208@gmail.com")
{
	
} else{
	header('location:../index.php');
}
?>