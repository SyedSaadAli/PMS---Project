<?php
include('security.php');
include('CheckLogin.php');
include('includes/header.php'); 
include('includes/navbar.php'); 
include('includes/patient.php'); 
?>



<div class="container-fluid">

	<!-- Datatables Example -->
	<div class="card shadow mb-4">

		<div class="card-header py-3">
			<form action="#" method="post">
				<h6 class="n-0 font-weight-bold text-primary">
                <center>

					<h2 style="color:#3851a2;">	PATIENT MEDICAL HISTORY </h2>
			
				</center>

				</form>

			</h6> </div>
		</div>
	</div>



	<div class="container-fluid">

		<!-- Datatables Example -->
		<div class="card shadow mb-4">
			<div class="card-header py-3">
				<h6 class="n-0 font-weight-bold text-primary"  > Patient MH


				</h6> </div>
				<div class="card-body">

					<?php  
					if(isset($_SESSION['success']) && $_SESSION['success'] != '')
					{
	echo '<h2 class="bg-primary" style="color:#21cdc0; text-align:center;"> '.$_SESSION['success'].' </h2>';# text-white
	unset($_SESSION['success']);
}
if(isset($_SESSION['status']) && $_SESSION['status'] != '' )
{
      echo '<h2 class="big-danger" style="color:#21cdc0; text-align:center;"> '.$_SESSION['status'].' </h2>';# text-white
      unset($_SESSION['status']);
  }
  ?>

  <div class="table-responsive">

  	<?php
  	$query = "SELECT * FROM search WHERE P_Image='$Patient_Image'";
  	$query_run = mysqli_query($connection, $query);

  	?>
  	<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
  		<thead>
  			<tr>
  				                   <td>Image</td>
                            <td>Name</td>
                            <td>Gender</td>
                            <td>Symptoms</td>
                            <td>Diagnosis</td>
                            <td>Medical_Prescription</td>
                            <td>Date</td>
                            <td>Enter Time</td>
                            <td>Exit Time</td>
                            <td>DOB</td>
                            <td>Phone</td>
                            <td>Email</td>
  			</tr>
  		</thead>
  		<tbody>
  			<?php
  			if(mysqli_num_rows($query_run) > 0)        
  			{
  				while($row = mysqli_fetch_assoc($query_run))
  				{

  					  	// $query1 = "SELECT * FROM patient WHERE Patient_ID=$Patient_ID";
  	       //      $query_run1 = mysqli_query($connection, $query1);
  	       //      $row1 = mysqli_fetch_assoc($query_run1)
  					?>
  					<tr>
  					               <td><img  src=../images/<?php echo $row['P_Image']; ?> width="145" height="135"></td>
                            <td><?php echo $row['P_Name']; ?></td>
                            <td><?php echo $row['P_Gender']; ?></td>
                            <td><?php echo $row['Symptoms']; ?></td>
                            <td><?php echo $row['Diagnosis']; ?></td>
                            <td><?php echo $row['MP']; ?></td>
                            <td><?php echo $row['Date']; ?></td>
                            <td><?php echo $row['Enter_Time']; ?></td>
                            <td><?php echo $row['Exit_Time']; ?></td>
                            <td><?php echo $row['P_DOB']; ?></td>
                            <td><?php echo $row['P_Phone']; ?></td>
                            <td><?php echo $row['P_Email']; ?></td>
  					</tr>
  					<?php
  				} 
  			}
  			else {
  				echo "No Record Found";
  			}
  			?>
  		</tbody>
  	</table>

  </div>
</div>
</div>
</div>
<!-- /.container-fluid -->


<?php 
include('includes/scripts.php'); 
include('includes/footer.php'); 
?>