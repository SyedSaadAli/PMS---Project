<?php
include('security.php');
include('CheckLogin.php');
include('includes/header.php'); 
include('includes/navbar.php'); 
?>



<head>
  <title>chart</title>
  <script src="https://code.highcharts.com/highcharts.js"></script>
  <script src="https://code.highcharts.com/modules/exporting.js"></script>
  <script src="https://code.highcharts.com/modules/export-data.js"></script>
  <script src="https://code.highcharts.com/modules/accessibility.js"></script>

  <style>

    <div class="container-fluid">

    <!-- Datatables Example -->
    <div class="card shadow mb-4">

    <div class="card-header py-3">
    <form action="#" method="">
    <h6 class="n-0 font-weight-bold text-primary">


    </form>

    </h6> </div>
    </div>
    </div>
    .highcharts-figure, .highcharts-data-table table {
      min-width: 320px; 
      max-width: 800px;
      margin: 1em auto;
    }

    .highcharts-data-table table {
     font-family: Verdana, sans-serif;
     border-collapse: collapse;
     border: 1px solid #EBEBEB;
     margin: 10px auto;
     text-align: center;
     width: 100%;
     max-width: 500px;
   }
   .highcharts-data-table caption {
    padding: 1em 0;
    font-size: 1.2em;
    color: #555;
  }
  .highcharts-data-table th {
   font-weight: 600;
   padding: 0.5em;
 }
 .highcharts-data-table td, .highcharts-data-table th, .highcharts-data-table caption {
  padding: 0.5em;
}
.highcharts-data-table thead tr, .highcharts-data-table tr:nth-child(even) {
  background: #f8f8f8;
}
.highcharts-data-table tr:hover {
  background: #f1f7ff;
}


input[type="number"] {
	min-width: 50px;
}

</style>
</head>

<body>
  <div class="container-fluid">

    <!-- Datatables Example -->
    <div class="card shadow mb-4">

      <div class="card-header py-3">
       
          <h6 class="n-0 font-weight-bold text-primary">

           <form action="Analysis.php" method="post">
           Analysis Date: <input type="date" name="Date" value="" >
  
            <button type="submit" name="Analysis" class="btn btn-primary" style="float: right;"> Run Analysis</button>
          </form>

    

      </h6> </div>
    </div>
  </div>

<?php 
if(isset($_POST['Analysis']))
{





  $start = $_POST['Date'];
$No_Patient=0;
$result=0;
 $Average_Time ="00:00:00";
 $Longest_Duration_Time ='00:00:00';
 $Shortest_Duration_Time ='24:60:60';
     $query = "SELECT * FROM invoice WHERE Date='$start'";
    $query_run = mysqli_query($connection, $query);

     if(mysqli_num_rows($query_run) > 0){
                while($row = mysqli_fetch_assoc($query_run)){
                  $x=1;
                 $No_Patient += $x ;

                }}

                  $query1 = "SELECT * FROM search WHERE Date='$start'";
    $query_run1 = mysqli_query($connection, $query1);

     if(mysqli_num_rows($query_run1) > 0){
                while($row1 = mysqli_fetch_assoc($query_run1)){
                  $Enter_Time = strtotime($row1['Enter_Time']);
                  $Exit_Time = strtotime($row1['Exit_Time']);

              $a = new DateTime($row1['Enter_Time']);
              $b = new DateTime($row1['Exit_Time']);
             
            
              $Time = $a->diff($b);
   
              $Current_Time = $Time->format("%H:%I:%S");

 $query = "INSERT INTO average (Time) VALUES 
    ('$Current_Time')";
    $query_run = mysqli_query($connection, $query);
 

            
              if($Longest_Duration_Time < $Current_Time){
                $Longest_Duration_Time =  $Current_Time;
       
              } 

                 if($Shortest_Duration_Time > $Current_Time){
                $Shortest_Duration_Time =  $Current_Time;

              } 

            }}
// $result = mysql_query("SELECT AVG(fieldName) AS avg FROM tableName");
// $row = mysql_fetch_assoc($result);
// echo $row['avg'];
            // SELECT AVG(Price) AS AveragePrice FROM Products;
            $Average_Time = "SELECT SEC_TO_TIME( AVG( TIME_TO_SEC(Time)) )AS avg FROM average";
              $res = mysqli_query($connection, $Average_Time);
              $row3 = mysqli_fetch_assoc($res);
            $Average = $row3['avg'];
 

            
?>
         <div class="details">
            <!-- Oredr Data List -->
            <div class="recentOrders">
                <div class="cardHeader" style="display: block;">
                   
                       <div class="ptext" style="width: 1000px; padding: 20px; background-color: #21cdc0;position: relative; color: white; left: 30px;">
                       <center> <h3>Number Of Patient On <?php echo $start; ?> </h3><br>
                        <h4><?php echo $No_Patient; ?></h4><br> </center>
                      </div><br>
                      <div class="ptext" style="width: 1000px; padding: 20px; background-color: #21cdc0;position: relative; color: white; left: 30px;">
                       <center>  <h3>Average Time Per Patient On <?php echo $start; ?> </h3><br>
                        <h4><?php echo $Average; ?></h4><br> </center>
                      </div><br>
                      <div class="ptext" style="width: 1000px; padding: 20px; background-color: #21cdc0;position: relative; color: white; left: 30px;">
                       <center>  <h3>Longest Duration Time Per Patient On <?php echo $start; ?> </h3><br>
                        <h4><?php echo $Longest_Duration_Time; ?></h4><br> </center>
                      </div><br>
                      <div class="ptext" style="width: 1000px; padding: 20px; background-color: #21cdc0;position: relative; color: white; left: 30px;">
                        <center> <h3>Shortest Duration Time Per Patient On <?php echo $start; ?> </h3><br>
                        <h4><?php echo $Shortest_Duration_Time; ?></h4><br> </center>
                      </div><br>
                      
                      </div>
                      </div>
                      </div>

                    


<?php
}

    $query5 = "DELETE FROM average";
    $query_run5 = mysqli_query($connection, $query5);
?>



  
</body>

