<?php
include('security.php');
include('CheckLogin.php');
include('includes/header.php'); 
include('includes/navbar.php'); 
include('includes/patient.php'); 

?>



         <div class="details">
            <!-- Oredr Data List -->
            <div class="recentOrders">
                <div class="cardHeader" style="display: block;">
                    <div class="slider" style="width: 1000px; padding: 20px; background-color: #21cdc0;position: relative; color: white; left: 30px;">
                        <form action="index.php" method="post">
                        <input type="text" name="Appointment_ID" placeholder="Appointment No" style="padding:10px 40px;"> 
                        <input type="submit" name="Appointment_ID_Btn" value="Submit" style="background-color: rgb(56, 81, 162); color: white; padding: 10px 20px;border: none; cursor: pointer; border-radius: 5px;">
                             </form>
                    </div><br> <br>

                    <h2 style="color:#3851a2;">Patient Form</h2> <br>
                    <!-- <a href="#" class="btn">View All</a> <br> <br> <br> -->
                    <div class="ptext" style="width: 1000px; padding: 20px; background-color: #21cdc0;position: relative; color: white; left: 30px;">
                        <h3>Patient Image</h3><br>
                        <img  src=../images/<?php echo $Patient_Image; ?> width="145" height="135"></div><br>
      <form action="code.php" method="post">
                        <?php 
                        if(isset($_POST['Appointment_ID_Btn'])){ 
                            $ID = $_POST['Appointment_ID'];
                              $query = "SELECT * FROM appointment WHERE Appointment_ID = $ID ";
                              $query_run = mysqli_query($connection, $query);
                              $row = mysqli_fetch_assoc($query_run);

                       

                            ?>
                        <div class="ptext" style="width: 1000px; padding: 20px; background-color: #21cdc0;position: relative; color: white; left: 30px;">
                        <h3>Patient Name</h3><br>
                        <input type="text" name="P_Name" placeholder="Patient Name" value="<?php echo $row['P_Name'] ?>" style="padding:10px 375px;"></div>
                        <br>
                        <div class="ptext" style="width: 1000px; padding: 20px; background-color: #21cdc0;position: relative; color: white; left: 30px;">
                        <h3>Patient DOB</h3><br>
                        <input type="date" name="P_DOB" placeholder="Patient DOB" value="<?php echo $row['P_DOB'] ?>" style="padding:10px 390px;"></div>
                        <br>
                        <div class="ptext" style="width: 1000px; padding: 20px; background-color: #21cdc0;position: relative; color: white; left: 30px;">
                        <h3>Patient Gender</h3><br>
                
                        <select type="text" name="P_Gender" value="<?php echo $row['P_Gender'] ?>" style="padding:10px 430px;">
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                        </select>
                    </div>
                        <br>
                        <div class="ptext" style="width: 1000px; padding: 20px; background-color: #21cdc0;position: relative; color: white; left: 30px;">
                        <h3>Patient Phone</h3><br>
                        <input type="number" name="P_Phone" placeholder="Patient Phone" value="<?php echo $row['P_Phone'] ?>" style="padding:10px 375px;"></div>
                        <br>
                        <div class="ptext" style="width: 1000px; padding: 20px; background-color: #21cdc0;position: relative; color: white; left: 30px;">
                        <h3>Patient Email</h3><br>
                        <input type="email" name="P_Email" placeholder="Patient Email" value="<?php echo $row['P_Email'] ?>" style="padding:10px 375px;"></div>

                         <input type="hidden" name="P_Name" value="<?php echo $row['P_Name']; ?>">
                         <input type="hidden" name="P_DOB" value="<?php echo $row['P_DOB']; ?>">
                         <input type="hidden" name="P_Gender" value="<?php echo $row['P_Gender']; ?>">
                         <input type="hidden" name="P_Phone" value="<?php echo $row['P_Phone']; ?>">
                         <input type="hidden" name="P_Email" value="<?php echo $row['P_Email']; ?>">
                        
                        <?php



                         }

                         ?>

                    <div class="symtomsbox" style="display: inline-block; width: 470px; height: 250px;left:10px;position:relative;background-color: #21cdc0; color: white; margin: 2%;padding: 10px 15px;">
                        <h3>Symptoms</h3> <br>
                        <textarea name="P_Symptoms" id="" placeholder="Symtoms" cols="48" rows="6"></textarea>
                    </div>
                    <div class="diagnosisbox" style="display: inline-block; width: 470px; height: 250px;  background-color: #21cdc0; color: white; margin: 2%; padding: 10px 15px;left:12px;position:relative;">
                        <h3>Diagnosis</h3><br>
                        <textarea name="P_Diagnosis" placeholder="diagnosis" id="" cols="48" rows="6"></textarea>
                    </div>
                    <div class="prescriptionbox" style="display: inline-block; width: 1000px; height: 250px;position:relative;left:2px; background-color: #21cdc0; color: white; margin: 2%; padding: 10px 15px;">
                        <h3>Prescription</h3><br>
                        <textarea name="P_Prescription" id="" placeholder="Prescription" cols="110" rows="6"></textarea>
                    </div>
                 <div class="buttons" style="margin: 0 auto; width: 150px;">
                    <button style="background-color: rgb(56, 81, 162); color: white; padding: 10px 40px; border: none;cursor: pointer; border-radius: 5px;" name="Form_btn" type="submit">Add</button>
                    
                 </div>
                 </form>
                </div>
              


<?php 
include('includes/scripts.php'); 
include('includes/footer.php'); 
?>