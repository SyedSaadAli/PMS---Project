<?php
include('security.php');
include('CheckLogin.php');
include('includes/header.php'); 
include('includes/navbar.php'); 


?>


         <div class="details">
            <!-- Oredr Data List -->
            <div class="recentOrders">
                <div class="cardHeader" style="display: block;">
                    <div class="slider" style="width: 1000px; padding: 20px; background-color: #21cdc0;position: relative; color: white; left: 30px;">
                        <form action="Add_Doctor.php" method="post">
                       
                    <center>  <input type="submit" name="Add_Doctor" value="Add Doctor" style="background-color: rgb(56, 81, 162); color: white; padding: 10px 20px;border: none; cursor: pointer; border-radius: 5px;"></center>  
                             </form>
                    </div><br> <br>

                    <h2 style="color:#3851a2;">Add Doctor</h2> <br>
                        <?php  
                   
if(isset($_SESSION['status']) && $_SESSION['status'] != '' )
{
      echo '<h2 class="big-danger" style="color:#21cdc0; text-align:center;"> '.$_SESSION['status'].' </h2>';# text-white
      unset($_SESSION['status']);
  }
  ?>
                    <!-- <a href="#" class="btn">View All</a> <br> <br> <br> -->
                   
      <form action="code.php" method="post">
                        <?php 
                        if(isset($_POST['Add_Doctor'])){ 

                            ?>
                      <br>  <div class="ptext" style="width: 1000px; padding: 20px; background-color: #21cdc0;position: relative; color: white; left: 30px;">
                        <h3>Doctor Name</h3><br>
                        <input type="text" name="D_Name" placeholder="Doctor Name" value="" style="padding:10px 375px;">
                    </div>
                        <br>
                        <div class="ptext" style="width: 1000px; padding: 20px; background-color: #21cdc0;position: relative; color: white; left: 30px;">
                        <h3>Doctor DOB</h3><br>
                        <input type="date" name="D_DOB" placeholder="Doctor DOB" value="" style="padding:10px 375px;">
                    </div>
                        <br>
                        <div class="ptext" style="width: 1000px; padding: 20px; background-color: #21cdc0;position: relative; color: white; left: 30px;">
                        <h3>Doctor Gender</h3><br>
                         <select type="text" name="D_Gender" value="" style="padding:10px 430px;">
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                        </select>
                    </div>
                        <br>
                        <div class="ptext" style="width: 1000px; padding: 20px; background-color: #21cdc0;position: relative; color: white; left: 30px;">
                        <h3>Doctor Email</h3><br>
                        <input type="email" name="D_Email" placeholder="Doctor Email" value="" style="padding:10px 375px;">
                    </div>
                        <br>
                        <div class="ptext" style="width: 1000px; padding: 20px; background-color: #21cdc0;position: relative; color: white; left: 30px;">
                        <h3>Doctor Phone</h3><br>
                        <input type="number" name="D_Phone" placeholder="Doctor Phone" value="" style="padding:10px 375px;">
                    </div>
                        <br>
                        <div class="ptext" style="width: 1000px; padding: 20px; background-color: #21cdc0;position: relative; color: white; left: 30px;">
                        <h3>Doctor Address</h3><br>
                        <input type="text" name="D_Address" placeholder="Doctor Address" value="" style="padding:10px 375px;">
                    </div>
                        <br>
                        <div class="ptext" style="width: 1000px; padding: 20px; background-color: #21cdc0;position: relative; color: white; left: 30px;">
                        <h3>Doctor Speciality</h3><br>
                        <input type="text" name="D_Speciality" placeholder="Doctor Speciality" value="" style="padding:10px 375px;">
                    </div>
                        <br>
                        <div class="ptext" style="width: 1000px; padding: 20px; background-color: #21cdc0;position: relative; color: white; left: 30px;">
                        <h3>Doctor Timing</h3><br>
                        <input type="text" name="D_Timing" placeholder="Doctor Timing" value="" style="padding:10px 375px;">
                    </div>
                        <br>
                        <div class="ptext" style="width: 1000px; padding: 20px; background-color: #21cdc0;position: relative; color: white; left: 30px;">
                        <h3>Doctor Shift</h3><br>
                        <input type="text" name="D_Shift" placeholder="Doctor Shift" value="" style="padding:10px 375px;">
                    </div>
                        <br>
                         <div class="ptext" style="width: 1000px; padding: 20px; background-color: #21cdc0;position: relative; color: white; left: 30px;">
                        <h3>Doctor Password</h3><br>
                        <input type="password" name="D_Password" placeholder="Doctor Password" value="" style="padding:10px 375px;">
                    </div>
                        <br>
                        <div class="buttons" style="margin: 0 auto; width: 150px;">
                    <button style="background-color: rgb(56, 81, 162); color: white; padding: 10px 40px; border: none;cursor: pointer; border-radius: 5px;" name="Add_btn" type="submit">Add</button>
                    
                 </div>

                        
                 </form>

                        <?php



                         }

                         ?>
                </div>
              




<?php 
include('includes/scripts.php'); 
include('includes/footer.php'); 
?>