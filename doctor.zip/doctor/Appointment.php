<?php
include('security.php');
include('CheckLogin.php');
include('includes/header.php'); 
include('includes/navbar_appointment.php'); 
?>



<div class="container-fluid">

	<!-- Datatables Example -->
	<div class="card shadow mb-4">

		<div class="card-header py-3">
			<form action="#" method="post">
				<h6 class="n-0 font-weight-bold text-primary">
                <center>

					<h2 style="color:#3851a2;">	PATIENTS APPOINTMENT </h2>
			
				</center>

				</form>

			</h6> </div>
		</div>
	</div>



	<div class="container-fluid">

		<!-- Datatables Example -->
		<div class="card shadow mb-4">
			<div class="card-header py-3">
				<h6 class="n-0 font-weight-bold text-primary"  > All Appointments


				</h6> </div>
				<div class="card-body">

					<?php  
					if(isset($_SESSION['success']) && $_SESSION['success'] != '')
					{
	echo '<h2 class="bg-primary" style="color:#21cdc0; text-align:center;"> '.$_SESSION['success'].' </h2>';# text-white
	unset($_SESSION['success']);
}
if(isset($_SESSION['status']) && $_SESSION['status'] != '' )
{
      echo '<h2 class="big-danger" style="color:#21cdc0; text-align:center;"> '.$_SESSION['status'].' </h2>';# text-white
      unset($_SESSION['status']);
  }
  ?>

  <div class="table-responsive">

  	<?php
  	$query = "SELECT * FROM appointment";
  	$query_run = mysqli_query($connection, $query);
  	?>
  	<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
  		<thead>
  			<tr>
  				                  <td>ID</td>
  				                  <td>Name</td>
                            <td>DOB</td>
                            <td>Gender</td>
                            <td>Phone</td>
                            <td>Email</td>
                            <td>Edit</td>
                            <td>Delete</td>
  			</tr>
  		</thead>
  		<tbody>
  			  <?php

                        if(isset($_POST['Search_btn'])){
                            $Search_Item = $_POST['Search_Item'];
                             $Search_Item = "%".$Search_Item."%";
                        $query1 = "SELECT * FROM appointment WHERE P_Name LIKE '".$Search_Item."' ";
                        $query_run1 = mysqli_query($connection, $query1);
                        if(mysqli_num_rows($query_run1) > 0)        
                        {
                            while($row1 = mysqli_fetch_assoc($query_run1))
                            {
                                $x=$row1['Appointment_ID'];
                                if(!isset($GLOBALS[$x]) ){
                                   $GLOBALS[$x]=$x;
                        ?>
                        <tr>
  					                <td><?php echo $row1['Appointment_ID']; ?></td>
  					                <td><?php echo $row1['P_Name']; ?></td>
                            <td><?php echo $row1['P_DOB']; ?></td>
                            <td><?php echo $row1['P_Gender']; ?></td>
                            <td><?php echo $row1['P_Phone']; ?></td>
                            <td><?php echo $row1['P_Email']; ?></td>
                          
  						<td style="padding: 0; margin: 0;">
  							<form action="Edit_Appointment.php" method="post">
  								<input type="hidden" name="Appointment_ID" value="<?php echo $row1['Appointment_ID']; ?>">
                                                
  								<button style="margin-left: 1rem; margin-top: 10px;" type="submit" name="appointment_edit_btn" class="btn btn-primary"> EDIT </button>
  							</form>
  						</td>
  						<td style="padding: 0; margin: 0;">
  							<form action="code.php" method="post">
  								<input type="hidden" name="Appointment_ID" value="<?php echo $row1['Appointment_ID']; ?>">
  								<button style="margin-left: 1rem; margin-top: 10px;" type="submit"  onclick="javascript: return confirm('Are you sure you want to DELETE this APPOINTMENT  ?')" name="delete_appointment_btn" class="btn btn-danger"> Delete </button>
  							</form>
  						</td>
  					</tr>


  			<?php

  			}}}}

  			    if(isset($_POST['Search_btn'])){
                            $Search_Item = $_POST['Search_Item'];
                             $Search_Item = "%".$Search_Item."%";
                        $query2 = "SELECT * FROM appointment WHERE P_DOB LIKE '".$Search_Item."' ";
                        $query_run2 = mysqli_query($connection, $query2);
                        if(mysqli_num_rows($query_run2) > 0)        
                        {
                            while($row2 = mysqli_fetch_assoc($query_run2))
                            {
                                $x=$row2['Appointment_ID'];
                                if(!isset($GLOBALS[$x]) ){
                                   $GLOBALS[$x]=$x;
                        ?>
                        <tr>
  					                <td><?php echo $row2['Appointment_ID']; ?></td>
  					                <td><?php echo $row2['P_Name']; ?></td>
                            <td><?php echo $row2['P_DOB']; ?></td>
                            <td><?php echo $row2['P_Gender']; ?></td>
                            <td><?php echo $row2['P_Phone']; ?></td>
                            <td><?php echo $row2['P_Email']; ?></td>
                          
  						<td style="padding: 0; margin: 0;">
  							<form action="Edit_Appointment.php" method="post">
  								<input type="hidden" name="Appointment_ID" value="<?php echo $row2['Appointment_ID']; ?>">
                                                
  								<button style="margin-left: 1rem; margin-top: 10px;" type="submit" name="appointment_edit_btn" class="btn btn-primary"> EDIT </button>
  							</form>
  						</td>
  						<td style="padding: 0; margin: 0;">
  							<form action="code.php" method="post">
  								<input type="hidden" name="Appointment_ID" value="<?php echo $row2['Appointment_ID']; ?>">
  								<button style="margin-left: 1rem; margin-top: 10px;" type="submit"  onclick="javascript: return confirm('Are you sure you want to DELETE this APPOINTMENT  ?')" name="delete_appointment_btn" class="btn btn-danger"> Delete </button>
  							</form>
  						</td>
  					</tr>


  			<?php

  			}}}}

  			    if(isset($_POST['Search_btn'])){
                            $Search_Item = $_POST['Search_Item'];
                             $Search_Item = "%".$Search_Item."%";
                        $query3 = "SELECT * FROM appointment WHERE P_Gender LIKE '".$Search_Item."' ";
                        $query_run3 = mysqli_query($connection, $query3);
                        if(mysqli_num_rows($query_run1) > 0)        
                        {
                            while($row1 = mysqli_fetch_assoc($query_run3))
                            {
                                $x=$row3['Appointment_ID'];
                                if(!isset($GLOBALS[$x]) ){
                                   $GLOBALS[$x]=$x;
                        ?>
                        <tr>
  					                <td><?php echo $row3['Appointment_ID']; ?></td>
  					                <td><?php echo $row3['P_Name']; ?></td>
                            <td><?php echo $row3['P_DOB']; ?></td>
                            <td><?php echo $row3['P_Gender']; ?></td>
                            <td><?php echo $row3['P_Phone']; ?></td>
                            <td><?php echo $row3['P_Email']; ?></td>
                          
  						<td style="padding: 0; margin: 0;">
  							<form action="Edit_Appointment.php" method="post">
  								<input type="hidden" name="Appointment_ID" value="<?php echo $row3['Appointment_ID']; ?>">
                                                
  								<button style="margin-left: 1rem; margin-top: 10px;" type="submit" name="appointment_edit_btn" class="btn btn-primary"> EDIT </button>
  							</form>
  						</td>
  						<td style="padding: 0; margin: 0;">
  							<form action="code.php" method="post">
  								<input type="hidden" name="Appointment_ID" value="<?php echo $row3['Appointment_ID']; ?>">
  								<button style="margin-left: 1rem; margin-top: 10px;" type="submit"  onclick="javascript: return confirm('Are you sure you want to DELETE this APPOINTMENT  ?')" name="delete_appointment_btn" class="btn btn-danger"> Delete </button>
  							</form>
  						</td>
  					</tr>


  			<?php

  			}}}}
    if(isset($_POST['Search_btn'])){
                            $Search_Item = $_POST['Search_Item'];
                             $Search_Item = "%".$Search_Item."%";
                        $query4 = "SELECT * FROM appointment WHERE P_Phone LIKE '".$Search_Item."' ";
                        $query_run4 = mysqli_query($connection, $query4);
                        if(mysqli_num_rows($query_run4) > 0)        
                        {
                            while($row4 = mysqli_fetch_assoc($query_run4))
                            {
                                $x=$row4['Appointment_ID'];
                                if(!isset($GLOBALS[$x]) ){
                                   $GLOBALS[$x]=$x;
                        ?>
                        <tr>
  					                <td><?php echo $row4['Appointment_ID']; ?></td>
  					                <td><?php echo $row4['P_Name']; ?></td>
                            <td><?php echo $row4['P_DOB']; ?></td>
                            <td><?php echo $row4['P_Gender']; ?></td>
                            <td><?php echo $row4['P_Phone']; ?></td>
                            <td><?php echo $row4['P_Email']; ?></td>
                          
  						<td style="padding: 0; margin: 0;">
  							<form action="Edit_Appointment.php" method="post">
  								<input type="hidden" name="Appointment_ID" value="<?php echo $row4['Appointment_ID']; ?>">
                                                
  								<button style="margin-left: 1rem; margin-top: 10px;" type="submit" name="appointment_edit_btn" class="btn btn-primary"> EDIT </button>
  							</form>
  						</td>
  						<td style="padding: 0; margin: 0;">
  							<form action="code.php" method="post">
  								<input type="hidden" name="Appointment_ID" value="<?php echo $row4['Appointment_ID']; ?>">
  								<button style="margin-left: 1rem; margin-top: 10px;" type="submit"  onclick="javascript: return confirm('Are you sure you want to DELETE this APPOINTMENT  ?')" name="delete_appointment_btn" class="btn btn-danger"> Delete </button>
  							</form>
  						</td>
  					</tr>


  			<?php

  			}}}}
    if(isset($_POST['Search_btn'])){
                            $Search_Item = $_POST['Search_Item'];
                             $Search_Item = "%".$Search_Item."%";
                        $query5 = "SELECT * FROM appointment WHERE P_Email LIKE '".$Search_Item."' ";
                        $query_run5 = mysqli_query($connection, $query5);
                        if(mysqli_num_rows($query_run5) > 0)        
                        {
                            while($row5 = mysqli_fetch_assoc($query_run5))
                            {
                                $x=$row5['Appointment_ID'];
                                if(!isset($GLOBALS[$x]) ){
                                   $GLOBALS[$x]=$x;
                        ?>
                        <tr>
  					                <td><?php echo $row5['Appointment_ID']; ?></td>
  					                <td><?php echo $row5['P_Name']; ?></td>
                            <td><?php echo $row5['P_DOB']; ?></td>
                            <td><?php echo $row5['P_Gender']; ?></td>
                            <td><?php echo $row5['P_Phone']; ?></td>
                            <td><?php echo $row5['P_Email']; ?></td>
                          
  						<td style="padding: 0; margin: 0;">
  							<form action="Edit_Appointment.php" method="post">
  								<input type="hidden" name="Appointment_ID" value="<?php echo $row5['Appointment_ID']; ?>">
                                                
  								<button style="margin-left: 1rem; margin-top: 10px;" type="submit" name="appointment_edit_btn" class="btn btn-primary"> EDIT </button>
  							</form>
  						</td>
  						<td style="padding: 0; margin: 0;">
  							<form action="code.php" method="post">
  								<input type="hidden" name="Appointment_ID" value="<?php echo $row5['Appointment_ID']; ?>">
  								<button style="margin-left: 1rem; margin-top: 10px;" type="submit"  onclick="javascript: return confirm('Are you sure you want to DELETE this APPOINTMENT  ?')" name="delete_appointment_btn" class="btn btn-danger"> Delete </button>
  							</form>
  						</td>
  					</tr>


  			<?php

  			}}}}
	if(mysqli_num_rows($query_run) > 0)        
  			{
  				while($row = mysqli_fetch_assoc($query_run))

  				{

  				                	$x=$row['Appointment_ID'];
  				                	 if(!isset($GLOBALS[$x]) ){
                                   $GLOBALS[$x]=$x;
  					?>
  					<tr>
  					 <td><?php echo $row['Appointment_ID']; ?></td>
  					 <td><?php echo $row['P_Name']; ?></td>
                            <td><?php echo $row['P_DOB']; ?></td>
                            <td><?php echo $row['P_Gender']; ?></td>
                            <td><?php echo $row['P_Phone']; ?></td>
                            <td><?php echo $row['P_Email']; ?></td>
                          
  						<td style="padding: 0; margin: 0;">
  							<form action="Edit_Appointment.php" method="post">
  								<input type="hidden" name="Appointment_ID" value="<?php echo $row['Appointment_ID']; ?>">
                                                
  								<button style="margin-left: 1rem; margin-top: 10px;" type="submit" name="appointment_edit_btn" class="btn btn-primary"> EDIT </button>
  							</form>
  						</td>
  						<td style="padding: 0; margin: 0;">
  							<form action="code.php" method="post">
  								<input type="hidden" name="Appointment_ID" value="<?php echo $row['Appointment_ID']; ?>">
  								<button style="margin-left: 1rem; margin-top: 10px;" type="submit"  onclick="javascript: return confirm('Are you sure you want to DELETE this APPOINTMENT  ?')" name="delete_appointment_btn" class="btn btn-danger"> Delete </button>
  							</form>
  						</td>
  					</tr>
  					<?php
  				} 
  			}}
  			else {
  				echo "No Record Found";
  			}
  		


?>
  		</tbody>
  	</table>

  </div>
</div>
</div>
</div>
<!-- /.container-fluid -->


<?php 
include('includes/scripts.php'); 
include('includes/footer.php'); 
?>