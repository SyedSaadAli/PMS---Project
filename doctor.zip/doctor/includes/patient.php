<?php
require_once "Classes/PHPExcel.php";
$path="../patients.csv";
$reader= PHPExcel_IOFactory::createReaderForFile($path);
$excel_Obj = $reader->load($path);

//Get the last sheet in excel
//$worksheet=$excel_Obj->getActiveSheet();

//Get the first sheet in excel
$worksheet=$excel_Obj->getSheet('0');


$lastRow = $worksheet->getHighestRow();
$colomncount = $worksheet->getHighestDataColumn();

$colomncount_number=PHPExcel_Cell::columnIndexFromString($colomncount);

for($col=0;$col<=$colomncount_number;$col++){
$worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex($col).$lastRow)->getValue();
$arr[$col] = $worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex($col).$lastRow)->getValue();

}

$Patient_Image = $arr[0];
$Enter_Time= $arr[1];
$Patient_Image = $Patient_Image.'.jpg';
// echo $Patient_Image;
// echo $Enter_Time;

?>
