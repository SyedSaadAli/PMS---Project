<style>
  

.btn-primary {
    color: #fff;
    background-color: #007bff;
    border-color: #007bff;
    margin-left: -31px;
    margin-top:-8px;
}

            .dropbtn {
              background-color: #007bff;
              color: white;
              padding: 5px;
              font-size: 16px;
              border-radius:6px;
              width: 160px;
              z-index: 1;
              position: relative;
              /* margin-left:0px; */
            }
            .justify-content-start{
              width:300%;
              position: relative;
              left:20%;
              
            }
            .dropdown {
              position: relative;
              display: inline-block;
              margin-left: 10px;
            }
            
            .dropdown-content {
              display: none;
              position: absolute;
              background-color: #f1f1f1;
              min-width: 160px;
             
             
            }
            
            .dropdown-content a {
              color: black;
              padding: 12px 16px;
              text-decoration: none;
              display: block;
              position: relative;
              z-index: 1;
              background-color: #fff;
              border-radius: 2px;
            }
            
            .dropdown-content a:hover {background-color: #ddd;}
            
            .dropdown:hover .dropdown-content {display: block;}
            
            .dropdown:hover .dropbtn {background-color: #054181;}

            .form-search{
              max-width:500px !important;
            }
            .form-search button{
              margin-top: 4px;
            }

            </style>
<!-- Sidebar -->
   <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">
    <br><br>
<!-- Sidebar - Brand -->
<a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.php">
  <div>
    
    <img height="155px" width="155px" src="logo/Medic-Logo-1(100X100).png">
  </div>
  
</a>

 <br><br> 
<!-- Divider -->
<hr class="sidebar-divider d-none d-md-block">
<!-- Heading -->
<div class="sidebar-heading">
  PATIENT
</div>

<!-- Nav Item - Tables -->
<li class="nav-item">
  <a class="nav-link" href="http://localhost/PMS/admin/index.php">
    <i class="fas fa-fw fa-tachometer-alt"></i>
    <span>Add Patient</span></a>
</li>
<li class="nav-item">
  <a class="nav-link" href="http://localhost/PMS/admin/Patients.php">
    <i class="fas fa-fw fa-table"></i>
    <span>Patient Records</span></a>
</li>
<li class="nav-item">
  <a class="nav-link" href="http://localhost/PMS/admin/Patients_MH.php">
    <i class="fas fa-fw fa-table"></i>
    <span>Patient Medical History</span></a>
</li>

<!-- Divider -->
<hr class="sidebar-divider d-none d-md-block">

<li class="nav-item">
  <a class="nav-link" href="http://localhost/PMS/admin/Revenue.php">
    <i class="fas fa-fw fa-chart-area"></i>
    <span>Revenue</span></a>
</li>
<!-- Divider -->
<hr class="sidebar-divider d-none d-md-block">

<li class="nav-item">
  <a class="nav-link" href="http://localhost/PMS/admin/Analysis.php">
    <i class="fas fa-fw fa-table"></i>
    <span>Analysis Report</span></a>
</li>
<!-- Divider -->
<hr class="sidebar-divider d-none d-md-block">

<li class="nav-item">
  <a class="nav-link" href="http://localhost/PMS/admin/Appointment.php">
    <i class="fas fa-fw fa-table"></i>
    <span>Appointments</span></a>
</li>
<!-- Divider -->
<hr class="sidebar-divider d-none d-md-block">

<li class="nav-item">
  <a class="nav-link" href="http://localhost/PMS/admin/Message.php">
    <i class="fas fa-fw fa-table"></i>
    <span>Messages</span></a>
</li>





<!-- Divider -->
<hr class="sidebar-divider d-none d-md-block">

<!-- Sidebar Toggler (Sidebar) -->
<div class="text-center d-none d-md-inline">
  <button class="rounded-circle border-0" id="sidebarToggle"></button>
</div>

</ul>
<!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
        <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">


        <div class="container body-content">
        



        <div class="container">
        
        
                            <div class="row justify-content-start" style="padding-top:10px;">
        
                        <div class="col" style="padding-top:10px;">
                          <form action="search.php" method="post" class="form-search">
        <input class="form-control" name='Search_Item' style="margin-left: 10px; margin-bottom: 10px" placeholder="Search here..."></input>
        
        
                        </div>
                        <div class="col" style="padding-top:10px;">
        <button  type='submit' name="Search_btn" style="height: 38px; margin-top:-2px; margin-left: 3px; " class="btn btn-primary">
            <i class="fa fa-search"></i>
        </button>
        
     
        </form>
                        </div>
                        
                        </div>
        
                       
        </div>
        
        
        
            </div>
          <!-- Sidebar Toggle (Topbar) -->
          <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
            <i class="fa fa-bars"></i>
          </button>

          <!-- Topbar Search -->
      


          <!-- Topbar Navbar -->
          <ul class="navbar-nav ml-auto">

            <!-- Nav Item - Search Dropdown (Visible Only XS) -->
          

            <!-- Nav Item - Alerts -->
          

            <!-- Nav Item - Messages -->
        

          

            <!-- Nav Item - User Information -->
            <li class="nav-item dropdown no-arrow">
              <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <span class="mr-2 d-none d-lg-inline text-gray-600 small">
                  Doctor
               <?php  
			   
			   //echo $_SESSION['Username']; 
			   ?>
                  
                </span>
                <img class="img-profile rounded-circle" src="https://source.unsplash.com/QAB-WJcbgJk/60x60">
              </a>
              <!-- Dropdown - User Information -->
              <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
              
                <a class="dropdown-item" href="logout.php" data-toggle="modal" data-target="#logoutModal">
                  <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                  Sign Out
                </a>
              </div>
            </li>

          </ul>

        </nav>
        <!-- End of Topbar -->


  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  
  <!-- Logout Modal-->
  <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">�</span>
          </button>
        </div>
        <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
        <div class="modal-footer">
          <button style="margin-bottom: 10px  ;" class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
<div style="margin:0 1rem; ">&nbsp;</div>
          <form action="logout.php" method="POST"> 
          
            <button type="submit" name="logout_btn" class="btn btn-primary">Logout</button>

          </form>


        </div>
      </div>
    </div>
  </div>