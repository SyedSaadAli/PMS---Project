<?php
include('security.php');
include('CheckLogin.php');
include('includes/header.php'); 
include('includes/navbar.php'); 


?>


         <div class="details">
            <!-- Oredr Data List -->
            <div class="recentOrders">
                <div class="cardHeader" style="display: block;">
                    <br> <br>

                    <h2 style="color:#3851a2;">Edit Patient Appointment</h2> <br>
                        <?php  
                   
if(isset($_SESSION['status']) && $_SESSION['status'] != '' )
{
      echo '<h2 class="big-danger" style="color:#21cdc0; text-align:center;"> '.$_SESSION['status'].' </h2>';# text-white
      unset($_SESSION['status']);
  }
  ?>
                    <!-- <a href="#" class="btn">View All</a> <br> <br> <br> -->
                   
      <form action="code.php" method="post">
                        <?php 
                        $Appointment_ID = $_POST['Appointment_ID'];
                    $query = "SELECT * FROM appointment WHERE Appointment_ID=$Appointment_ID";
                     $query_run = mysqli_query($connection, $query);
                     $row = mysqli_fetch_assoc($query_run);

                            ?>
                      <br>  <div class="ptext" style="width: 1000px; padding: 20px; background-color: #21cdc0;position: relative; color: white; left: 30px;">
                        <h3>Patient Name</h3><br>
                        <input type="text" name="E_P_Name"  value="<?php echo $row['P_Name']; ?>" style="padding:10px 375px;">
                    </div>
                        <br>
                        <div class="ptext" style="width: 1000px; padding: 20px; background-color: #21cdc0;position: relative; color: white; left: 30px;">
                        <h3>Patient DOB</h3><br>
                        <input type="date" name="E_P_DOB"  value="<?php echo $row['P_DOB']; ?>" style="padding:10px 375px;">
                    </div>
                        <br>
                        <div class="ptext" style="width: 1000px; padding: 20px; background-color: #21cdc0;position: relative; color: white; left: 30px;">
                        <h3>Patient Gender</h3><br>
                         <select type="text" name="E_P_Gender" value="<?php echo $row['P_Gender']; ?>" style="padding:10px 430px;">
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                        </select>
                    </div>
                        <br>
                        <div class="ptext" style="width: 1000px; padding: 20px; background-color: #21cdc0;position: relative; color: white; left: 30px;">
                        <h3>Patient Phone</h3><br>
                        <input type="number" name="E_P_Phone"  value="<?php echo $row['P_Phone']; ?>" style="padding:10px 375px;">
                    </div>
                        <br>
                        <div class="ptext" style="width: 1000px; padding: 20px; background-color: #21cdc0;position: relative; color: white; left: 30px;">
                        <h3>Patient Email</h3><br>
                        <input type="email" name="E_P_Email"  value="<?php echo $row['P_Email']; ?>" style="padding:10px 375px;">
                    </div>
                        <br>
                        
                        
                        <br>
                        <input type="hidden" name="Appointment_ID" value="<?php echo $row['Appointment_ID']; ?>">
                        <div class="buttons" style="margin: 0 auto; width: 150px;">
                    <button style="background-color: rgb(56, 81, 162); color: white; padding: 10px 40px; border: none;cursor: pointer; border-radius: 5px;" name="Appoitment_Edit_btn" type="submit">Edit</button>
                    
                 </div>

                        
                 </form>

                        <?php




                         ?>
                </div>
              




<?php 
include('includes/scripts.php'); 
include('includes/footer.php'); 
?>