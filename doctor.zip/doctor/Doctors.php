<?php
include('security.php');
include('CheckLogin.php');
include('includes/header.php'); 
include('includes/navbar.php'); 
?>



<div class="container-fluid">

	<!-- Datatables Example -->
	<div class="card shadow mb-4">

		<div class="card-header py-3">
			<form action="#" method="post">
				<h6 class="n-0 font-weight-bold text-primary">
                <center>

					<h2 style="color:#3851a2;">	DOCTOR RECORDS </h2>
			
				</center>

				</form>

			</h6> </div>
		</div>
	</div>



	<div class="container-fluid">

		<!-- Datatables Example -->
		<div class="card shadow mb-4">
			<div class="card-header py-3">
				<h6 class="n-0 font-weight-bold text-primary"  > All Doctors


				</h6> </div>
				<div class="card-body">

					<?php  
					if(isset($_SESSION['success']) && $_SESSION['success'] != '')
					{
	echo '<h2 class="bg-primary" style="color:#21cdc0; text-align:center;"> '.$_SESSION['success'].' </h2>';# text-white
	unset($_SESSION['success']);
}
if(isset($_SESSION['status']) && $_SESSION['status'] != '' )
{
      echo '<h2 class="big-danger" style="color:#21cdc0; text-align:center;"> '.$_SESSION['status'].' </h2>';# text-white
      unset($_SESSION['status']);
  }
  ?>

  <div class="table-responsive">

  	<?php
  	$query = "SELECT * FROM doctor";
  	$query_run = mysqli_query($connection, $query);
  	?>
  	<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
  		<thead>
  			<tr>
  				                  <td>Name</td>
                            <td>Gender</td>
                            <td>Speciality</td>
                            <td>Timing</td>
                            <td>Shift</td>
                            <td>Email</td>
                            <td>Password</td>
                            <td>DOB</td>
                            <td>Phone</td>
                            <td>Address</td>
                            <td>Edit</td>
                            <td>Delete</td>
  			</tr>
  		</thead>
  		<tbody>
  			<?php
  			if(mysqli_num_rows($query_run) > 0)        
  			{
  				while($row = mysqli_fetch_assoc($query_run))
  				{
  					?>
  					<tr>
  					 <td><?php echo $row['D_Name']; ?></td>
                            <td><?php echo $row['D_Gender']; ?></td>
                            <td><?php echo $row['D_Speciality']; ?></td>
                            <td><?php echo $row['D_Timing']; ?></td>
                            <td><?php echo $row['D_Shift']; ?></td>
                            <td><?php echo $row['D_Email']; ?></td>
                            <td><?php echo $row['Password']; ?></td>
                            <td><?php echo $row['D_DOB']; ?></td>
                            <td><?php echo $row['D_Contact_No']; ?></td>
                            <td><?php echo $row['D_Address']; ?></td>
  						<td style="padding: 0; margin: 0;">
  							<form action="Edit_Doctor.php" method="post">
  								<input type="hidden" name="Doctor_ID" value="<?php echo $row['Doctor_ID']; ?>">
                                                
  								<button style="margin-left: 1rem; margin-top: 10px;" type="submit" name="doctor_edit_btn" class="btn btn-primary"> EDIT </button>
  							</form>
  						</td>
  						<td style="padding: 0; margin: 0;">
  							<form action="code.php" method="post">
  								<input type="hidden" name="Doctor_ID" value="<?php echo $row['Doctor_ID']; ?>">
  								<button style="margin-left: 1rem; margin-top: 10px;" type="submit"  onclick="javascript: return confirm('Are you sure you want to DELETE this DOCTOR  ?')" name="delete_doctor_btn" class="btn btn-danger"> Delete </button>
  							</form>
  						</td>
  					</tr>
  					<?php
  				} 
  			}
  			else {
  				echo "No Record Found";
  			}
  			?>
  		</tbody>
  	</table>

  </div>
</div>
</div>
</div>
<!-- /.container-fluid -->


<?php 
include('includes/scripts.php'); 
include('includes/footer.php'); 
?>