<?php 
include('security.php');

date_default_timezone_set("Asia/Karachi");

 $query = "SELECT * FROM invoice";
    $query_run = mysqli_query($connection, $query);

     if(mysqli_num_rows($query_run) > 0){
                while($row = mysqli_fetch_assoc($query_run)){
                

                $Image = $row['Image'];
                $P_Name = $row['P_Name'];
                $Fees = $row['Fees'];
                $Medical_Prescription = $row['Medical_Prescription'];
                $Symptoms = $row['Symptoms'];
                $Patient_ID = $row['Patient_ID'];

                }}

                     $query1 = "SELECT * FROM medicalhistory";
    $query_run1 = mysqli_query($connection, $query1);

     if(mysqli_num_rows($query_run1) > 0){
                while($row1 = mysqli_fetch_assoc($query_run1)){
                    $MH_ID = $row1['MH_ID'];

                }}

$Exit_Time = date("H:i:s");
        $query2 = "UPDATE medicalhistory SET Exit_Time='$Exit_Time'  WHERE MH_ID='$MH_ID' ";
        $query_run2 = mysqli_query($connection, $query2);



                     $query3 = "SELECT * FROM search";
    $query_run3 = mysqli_query($connection, $query3);

     if(mysqli_num_rows($query_run3) > 0){
                while($row3 = mysqli_fetch_assoc($query_run3)){
                    $Search_ID = $row3['Search_ID'];

                }}

$Exit_Time = date("H:i:s");
        $query4 = "UPDATE search SET Exit_Time='$Exit_Time'  WHERE Search_ID='$Search_ID' ";
        $query_run4 = mysqli_query($connection, $query4);


?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css" integrity="sha384-zCbKRCUGaJDkqS1kPbPd7TveP5iyJE0EjAuZQTgFLD2ylzuqKfdKlfG/eSrtxUkn" crossorigin="anonymous">
<script type="text/javascript" src="https://code.jquery.com/jquery-3.5.1.min.js"></script>

    <link rel="stylesheet" type="text/css" href="style1.css">
    <script src="https://kit.fontawesome.com/06a786625d.js" crossorigin="anonymous"></script>  

    <title>Invoice</title>
  </head>
  <body>
  
  <!--Author      : @arboshiki-->
<div id="invoice">
    <div class="invoice overflow-auto">
        <div style="min-width: 600px">
            <header>
                <div class="row">
                    <div class="col">
                    
                            <div style="background-color:#38467b;width:100%;height: 100px; border-radius: 50px;">
                                <img src="images/Logo-1.png" width="300px;" style="position: relative; bottom: 90px; right: 35px;">
                           </div>
                            
                            <br>
                    </div>
                </div>
            </header>
            <main>
                <div class="row contacts">
                    <div class="aliment_set">
                    <!--   <div class="clientlogo"></div> -->
                    <div class="row"> <img  src=../images/<?php echo $Image; ?> width="145" height="135">
                       <div class="info">
                          <h2 style="color: #38467b;"><b>Client Name</b></h2>
                          <h3 style="color:#26bfac ;"><b><?php echo $P_Name; ?></b></h3>
                             <p style="color: #26bfac;"><b>Medic@gmail.com</b></br>
                                 <b>0331-1321578</b></br>
                         </div></div>
                    </div>
                    <div class="col invoice-details" style="margin-top: 120px;">
                        <div class="date" style="margin: 10px; display: inline; color:#38467b ;"><b>Date: <big><?php echo date("Y/m/d"); ?></big></b></div> <div class="date" style="display: inline ; color:#38467b;"> <b>Time: <big><?php echo date("H:i:s"); ?></big></b></div><div class="date" style="display: inline; color:#38467b"> <b>Fee: <big>1000</big></b></div>
                    </div>
                </div>
                <table border="1" cellspacing="0" cellpadding="0">
                    <thead>
                        <tr>
                            <th style="background-color: #26bfac; color:  #38467b; font-size: 23px;"><b>#</b></th>
                            <th style="background-color: #26bfac; color:  #38467b; font-size: 23px;" class="text-center"><b>MEDICAL PRESCRIPTION</b></th>
                            <th style="background-color: #26bfac; color:  #38467b; font-size: 23px;" class="text-center"><b>PATIENT SYMPTOMS</b></th>
                            <th style="background-color: #26bfac; color:  #38467b; font-size: 23px;" class="text-center"><b>PATIENT NAME</b></th>
                            <th style="background-color: #26bfac; color:  #38467b; font-size: 23px;" class="text-center"><b>FEES</b></th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td class="text-center no">1</td>
                            <td class="text-left"><?php echo $Medical_Prescription; ?><h3></h3></td>
                            <td class="text-center unit"><?php echo $Symptoms; ?></td>
                            <td class=" text-center qty"><?php echo $P_Name; ?></td>
                            <td class="text-center total"><?php echo $Fees; ?></td>
                        </tr>
                       
                    </tbody>
                 <!--    <tfoot>
                        <tr>
                            <td colspan="2"></td>
                            <td colspan="2" class="text-center" style="color: #26bfac;"><b>SUBTOTAL:</b></td>
                            <td class="text-center">Please enter the TOTAL AMOUNT</td>
                        </tr>
                        <tr>
                            <td colspan="2">
                              <h6 class="text-left"><b style="position: relative;bottom: 50px; color: #38467b;">Terms and Condication:</b></h6>
                            </td>
                            <td colspan="2"  class="text-center" style="color: #26bfac;"><b>TAX 25%:</b></td>
                            <td class="text-center">Please enter the TOTAL AMOUNT</td>
                        </tr>
                        <tr>
                            <td colspan="2"></td>
                            <td colspan="2"  class="text-center" style="color: #26bfac;"><b>GRAND TOTAL:</b></td>
                            <td class="text-center">Please enter the GRAND TOTAL</td>
                        </tr>
                    </tfoot> -->
                </table>
                <br>
                <br>
                <br>
                <br>
                <div class="notices">
                  <div class="thanks"><b style="color: #26bfac;">Thank you!</b></div>
                   
                     <div class="toolbar hidden-print">
        <hr>
    </div>
                </div>
            </main>
            <footer>
                Invoice was created on a computer and is valid without the signature and seal.
            </footer>
        </div>
        <!--DO NOT DELETE THIS div. IT is responsible for showing footer always at the bottom-->
        <div></div>
    </div>
</div>
<div class="text-center"><form>
    <button type="button" value="Print this page" onClick="window.print()" class="btn btn-primary mr-3">Print</button>
    <a href="index.php">
    <button type="button" value="Print this page"class="btn btn-primary">Back</button>
</a></form></div>


   
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-fQybjgWLrvvRgtW6bFlB7jaZrFsaBXjsOMm/tB9LTS58ONXgqbR9W8oWht/amnpF" crossorigin="anonymous"></script>
  </body>
</html>