<?php
include('security.php');
include('CheckLogin.php');
include('includes/header.php'); 
include('includes/navbar_message.php'); 
?>



<div class="container-fluid">

	<!-- Datatables Example -->
	<div class="card shadow mb-4">

		<div class="card-header py-3">
			<form action="#" method="post">
				<h6 class="n-0 font-weight-bold text-primary">
                <center>

					<h2 style="color:#3851a2;"> USER MESSAGES </h2>
			
				</center>

				</form>

			</h6> </div>
		</div>
	</div>



	<div class="container-fluid">

		<!-- Datatables Example -->
		<div class="card shadow mb-4">
			<div class="card-header py-3">
				<h6 class="n-0 font-weight-bold text-primary"  > All Messages


				</h6> </div>
				<div class="card-body">

					<?php  
					if(isset($_SESSION['success']) && $_SESSION['success'] != '')
					{
	echo '<h2 class="bg-primary" style="color:#21cdc0; text-align:center;"> '.$_SESSION['success'].' </h2>';# text-white
	unset($_SESSION['success']);
}
if(isset($_SESSION['status']) && $_SESSION['status'] != '' )
{
      echo '<h2 class="big-danger" style="color:#21cdc0; text-align:center;"> '.$_SESSION['status'].' </h2>';# text-white
      unset($_SESSION['status']);
  }
  ?>

  <div class="table-responsive">

  	<?php
  	$query = "SELECT * FROM contact";
  	$query_run = mysqli_query($connection, $query);
  	?>
  	<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
  		<thead>
  			<tr>
  				                  <td>Name</td>
                            <td>Email</td>
                            <td>Phone</td>
                            <td>Message</td>
                            <td>Delete</td>
  			</tr>
  		</thead>
  		<tbody>
  			<?php

                           if(isset($_POST['Search_btn'])){
                            $Search_Item = $_POST['Search_Item'];
                             $Search_Item = "%".$Search_Item."%";
                        $query1 = "SELECT * FROM contact WHERE Name LIKE '".$Search_Item."' ";
                        $query_run1 = mysqli_query($connection, $query1);
                        if(mysqli_num_rows($query_run1) > 0)        
                        {
                            while($row1 = mysqli_fetch_assoc($query_run1))
                            {
                                $x=$row1['Contact_ID'];
                                if(!isset($GLOBALS[$x]) ){
                                   $GLOBALS[$x]=$x;
                           ?>
	<tr>
  					 <td><?php echo $row1['Name']; ?></td>
                            <td><?php echo $row1['Email']; ?></td>
                            <td><?php echo $row1['Phone']; ?></td>
                            <td><?php echo $row1['Message']; ?></td>
                            
  						<td style="padding: 0; margin: 0;">
  							<form action="code.php" method="post">
  								<input type="hidden" name="Contact_ID" value="<?php echo $row1['Contact_ID']; ?>">
  								<button style="margin-left: 1rem; margin-top: 10px;" type="submit"  onclick="javascript: return confirm('Are you sure you want to DELETE this MESSAGE  ?')" name="delete_message_btn" class="btn btn-danger"> Delete </button>
  							</form>
  						</td>
  					</tr>


<?php

}}}}

          if(isset($_POST['Search_btn'])){
                            $Search_Item = $_POST['Search_Item'];
                             $Search_Item = "%".$Search_Item."%";
                        $query2 = "SELECT * FROM contact WHERE Email LIKE '".$Search_Item."' ";
                        $query_run2 = mysqli_query($connection, $query2);
                        if(mysqli_num_rows($query_run2) > 0)        
                        {
                            while($row2 = mysqli_fetch_assoc($query_run2))
                            {
                                $x=$row2['Contact_ID'];
                                if(!isset($GLOBALS[$x]) ){
                                   $GLOBALS[$x]=$x;
                           ?>
	<tr>
  					 <td><?php echo $row2['Name']; ?></td>
                            <td><?php echo $row2['Email']; ?></td>
                            <td><?php echo $row2['Phone']; ?></td>
                            <td><?php echo $row2['Message']; ?></td>
                            
  						<td style="padding: 0; margin: 0;">
  							<form action="code.php" method="post">
  								<input type="hidden" name="Contact_ID" value="<?php echo $row2['Contact_ID']; ?>">
  								<button style="margin-left: 1rem; margin-top: 10px;" type="submit"  onclick="javascript: return confirm('Are you sure you want to DELETE this MESSAGE  ?')" name="delete_message_btn" class="btn btn-danger"> Delete </button>
  							</form>
  						</td>
  					</tr>


<?php

}}}}
          if(isset($_POST['Search_btn'])){
                            $Search_Item = $_POST['Search_Item'];
                             $Search_Item = "%".$Search_Item."%";
                        $query3 = "SELECT * FROM contact WHERE Phone LIKE '".$Search_Item."' ";
                        $query_run3 = mysqli_query($connection, $query3);
                        if(mysqli_num_rows($query_run3) > 0)        
                        {
                            while($row3 = mysqli_fetch_assoc($query_run3))
                            {
                                $x=$row3['Contact_ID'];
                                if(!isset($GLOBALS[$x]) ){
                                   $GLOBALS[$x]=$x;
                           ?>
	<tr>
  					 <td><?php echo $row3['Name']; ?></td>
                            <td><?php echo $row3['Email']; ?></td>
                            <td><?php echo $row3['Phone']; ?></td>
                            <td><?php echo $row3['Message']; ?></td>
                            
  						<td style="padding: 0; margin: 0;">
  							<form action="code.php" method="post">
  								<input type="hidden" name="Contact_ID" value="<?php echo $row3['Contact_ID']; ?>">
  								<button style="margin-left: 1rem; margin-top: 10px;" type="submit"  onclick="javascript: return confirm('Are you sure you want to DELETE this MESSAGE  ?')" name="delete_message_btn" class="btn btn-danger"> Delete </button>
  							</form>
  						</td>
  					</tr>


<?php

}}}}
          if(isset($_POST['Search_btn'])){
                            $Search_Item = $_POST['Search_Item'];
                             $Search_Item = "%".$Search_Item."%";
                        $query4 = "SELECT * FROM contact WHERE Message LIKE '".$Search_Item."' ";
                        $query_run4 = mysqli_query($connection, $query4);
                        if(mysqli_num_rows($query_run4) > 0)        
                        {
                            while($row4 = mysqli_fetch_assoc($query_run4))
                            {
                                $x=$row4['Contact_ID'];
                                if(!isset($GLOBALS[$x]) ){
                                   $GLOBALS[$x]=$x;
                           ?>
                 	<tr>
  					 <td><?php echo $row4['Name']; ?></td>
                            <td><?php echo $row4['Email']; ?></td>
                            <td><?php echo $row4['Phone']; ?></td>
                            <td><?php echo $row4['Message']; ?></td>
                            
  						<td style="padding: 0; margin: 0;">
  							<form action="code.php" method="post">
  								<input type="hidden" name="Contact_ID" value="<?php echo $row4['Contact_ID']; ?>">
  								<button style="margin-left: 1rem; margin-top: 10px;" type="submit"  onclick="javascript: return confirm('Are you sure you want to DELETE this MESSAGE  ?')" name="delete_message_btn" class="btn btn-danger"> Delete </button>
  							</form>
  						</td>
  					</tr>


<?php

}}}}

  			if(mysqli_num_rows($query_run) > 0)        
  			{
  				while($row = mysqli_fetch_assoc($query_run))
  				{
  					                     $x=$row['Contact_ID'];
                                if(!isset($GLOBALS[$x]) ){
                                   $GLOBALS[$x]=$x;
  					?>
  					<tr>
  					 <td><?php echo $row['Name']; ?></td>
                            <td><?php echo $row['Email']; ?></td>
                            <td><?php echo $row['Phone']; ?></td>
                            <td><?php echo $row['Message']; ?></td>
                            
  						<td style="padding: 0; margin: 0;">
  							<form action="code.php" method="post">
  								<input type="hidden" name="Contact_ID" value="<?php echo $row['Contact_ID']; ?>">
  								<button style="margin-left: 1rem; margin-top: 10px;" type="submit"  onclick="javascript: return confirm('Are you sure you want to DELETE this MESSAGE  ?')" name="delete_message_btn" class="btn btn-danger"> Delete </button>
  							</form>
  						</td>
  					</tr>
  					<?php
  				} 
  			}}
  			else {
  				echo "No Record Found";
  			}
  			?>
  		</tbody>
  	</table>

  </div>
</div>
</div>
</div>
<!-- /.container-fluid -->


<?php 
include('includes/scripts.php'); 
include('includes/footer.php'); 
?>