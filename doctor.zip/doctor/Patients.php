<?php
include('security.php');
include('CheckLogin.php');
include('includes/header.php'); 
include('includes/navbar_patient.php'); 
?>



<div class="container-fluid">

	<!-- Datatables Example -->
	<div class="card shadow mb-4">

		<div class="card-header py-3">
			<form action="#" method="post">
				<h6 class="n-0 font-weight-bold text-primary">
                <center>

					<h2 style="color:#3851a2;">	PATIENT RECORDS </h2>
			
				</center>

				</form>

			</h6> </div>
		</div>
	</div>



	<div class="container-fluid">

		<!-- Datatables Example -->
		<div class="card shadow mb-4">
			<div class="card-header py-3">
				<h6 class="n-0 font-weight-bold text-primary"  > All Patients


				</h6> </div>
				<div class="card-body">

					<?php  
					if(isset($_SESSION['success']) && $_SESSION['success'] != '')
					{
	echo '<h2 class="bg-primary" style="color:#21cdc0; text-align:center;"> '.$_SESSION['success'].' </h2>';# text-white
	unset($_SESSION['success']);
}
if(isset($_SESSION['status']) && $_SESSION['status'] != '' )
{
      echo '<h2 class="big-danger" style="color:#21cdc0; text-align:center;"> '.$_SESSION['status'].' </h2>';# text-white
      unset($_SESSION['status']);
  }
  ?>

  <div class="table-responsive">

  	<?php
  	// $query = "SELECT * FROM medicalhistory";
  	// $query_run = mysqli_query($connection, $query);
  	?>
  	<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
  		<thead>
  			<tr>
  				                  <td>Image</td>
                            <td>Name</td>
                            <td>Gender</td>
                            <td>Symptoms</td>
                            <td>Diagnosis</td>
                            <td>Medical_Prescription</td>
                            <td>Date</td>
                            <td>Enter Time</td>
                            <td>Exit Time</td>
                            <td>DOB</td>
                            <td>Phone</td>
                            <td>Email</td>
  			</tr>
  		</thead>
  		<tbody>
  			<?php


                           if(isset($_POST['Search_btn'])){
                            $Search_Item = $_POST['Search_Item'];
                             $Search_Item = "%".$Search_Item."%";

                        $query10 = "SELECT * FROM search WHERE P_Name LIKE '".$Search_Item."' ";
                        $query_run10 = mysqli_query($connection, $query10);

                        if(mysqli_num_rows($query_run10) > 0)        
                        {
                            while($row10 = mysqli_fetch_assoc($query_run10))
                            {
                                $x=$row10['Search_ID'];
                                if(!isset($GLOBALS[$x]) ){
                                   $GLOBALS[$x]=$x;
?>
<tr>
  					                <td><img  src=../images/<?php echo $row10['P_Image']; ?> width="145" height="135"></td>
                            <td><?php echo $row10['P_Name']; ?></td>
                            <td><?php echo $row10['P_Gender']; ?></td>
                            <td><?php echo $row10['Symptoms']; ?></td>
                            <td><?php echo $row10['Diagnosis']; ?></td>
                            <td><?php echo $row10['MP']; ?></td>
                            <td><?php echo $row10['Date']; ?></td>
                            <td><?php echo $row10['Enter_Time']; ?></td>
                            <td><?php echo $row10['Exit_Time']; ?></td>
                            <td><?php echo $row10['P_DOB']; ?></td>
                            <td><?php echo $row10['P_Phone']; ?></td>
                            <td><?php echo $row10['P_Email']; ?></td>
  					</tr>
  					<?php

                                 }}}}


                           if(isset($_POST['Search_btn'])){
                            $Search_Item = $_POST['Search_Item'];
                             $Search_Item = "%".$Search_Item."%";
                             
                        $query11 = "SELECT * FROM search WHERE P_DOB LIKE '".$Search_Item."' ";
                        $query_run11 = mysqli_query($connection, $query11);

                        if(mysqli_num_rows($query_run11) > 0)        
                        {
                            while($row11 = mysqli_fetch_assoc($query_run11))
                            {
                                $x=$row11['Search_ID'];
                                if(!isset($GLOBALS[$x])){
                                   $GLOBALS[$x]=$x;
?>`
<tr>
  					                <td><img  src=../images/<?php echo $row11['P_Image']; ?> width="145" height="135"></td>
                            <td><?php echo $row11['P_Name']; ?></td>
                            <td><?php echo $row11['P_Gender']; ?></td>
                            <td><?php echo $row11['Symptoms']; ?></td>
                            <td><?php echo $row11['Diagnosis']; ?></td>
                            <td><?php echo $row11['MP']; ?></td>
                            <td><?php echo $row11['Date']; ?></td>
                            <td><?php echo $row11['Enter_Time']; ?></td>
                            <td><?php echo $row11['Exit_Time']; ?></td>
                            <td><?php echo $row11['P_DOB']; ?></td>
                            <td><?php echo $row11['P_Phone']; ?></td>
                            <td><?php echo $row11['P_Email']; ?></td>
  					</tr>
  					<?php

                                 }}}}

  if(isset($_POST['Search_btn'])){
                            $Search_Item = $_POST['Search_Item'];
                             $Search_Item = "%".$Search_Item."%";
                             
                        $query12 = "SELECT * FROM search WHERE P_Phone LIKE '".$Search_Item."' ";
                        $query_run12 = mysqli_query($connection, $query12);

                        if(mysqli_num_rows($query_run12) > 0)        
                        {
                            while($row12 = mysqli_fetch_assoc($query_run12))
                            {
                                $x=$row12['Search_ID'];
                                if(!isset($GLOBALS[$x]) ){
                                   $GLOBALS[$x]=$x;
?>
<tr>
  					                <td><img  src=../images/<?php echo $row12['P_Image']; ?> width="145" height="135"></td>
                            <td><?php echo $row12['P_Name']; ?></td>
                            <td><?php echo $row12['P_Gender']; ?></td>
                            <td><?php echo $row12['Symptoms']; ?></td>
                            <td><?php echo $row12['Diagnosis']; ?></td>
                            <td><?php echo $row12['MP']; ?></td>
                            <td><?php echo $row12['Date']; ?></td>
                            <td><?php echo $row12['Enter_Time']; ?></td>
                            <td><?php echo $row12['Exit_Time']; ?></td>
                            <td><?php echo $row12['P_DOB']; ?></td>
                            <td><?php echo $row12['P_Phone']; ?></td>
                            <td><?php echo $row12['P_Email']; ?></td>
  					</tr>
  					<?php

                                 }}}}
                                   if(isset($_POST['Search_btn'])){
                            $Search_Item = $_POST['Search_Item'];
                             $Search_Item = "%".$Search_Item."%";
                             
                        $query13 = "SELECT * FROM search WHERE P_Email LIKE '".$Search_Item."' ";
                        $query_run13 = mysqli_query($connection, $query13);

                        if(mysqli_num_rows($query_run13) > 0)        
                        {
                            while($row13 = mysqli_fetch_assoc($query_run13))
                            {
                                $x=$row13['Search_ID'];
                                if(!isset($GLOBALS[$x]) ){
                                   $GLOBALS[$x]=$x;
?>
<tr>
  					                <td><img  src=../images/<?php echo $row13['P_Image']; ?> width="145" height="135"></td>
                            <td><?php echo $row13['P_Name']; ?></td>
                            <td><?php echo $row13['P_Gender']; ?></td>
                            <td><?php echo $row13['Symptoms']; ?></td>
                            <td><?php echo $row13['Diagnosis']; ?></td>
                            <td><?php echo $row13['MP']; ?></td>
                            <td><?php echo $row13['Date']; ?></td>
                            <td><?php echo $row13['Enter_Time']; ?></td>
                            <td><?php echo $row13['Exit_Time']; ?></td>
                            <td><?php echo $row13['P_DOB']; ?></td>
                            <td><?php echo $row13['P_Phone']; ?></td>
                            <td><?php echo $row13['P_Email']; ?></td>
  					</tr>
  					<?php

                                 }}}}
                                   if(isset($_POST['Search_btn'])){
                            $Search_Item = $_POST['Search_Item'];
                             $Search_Item = "%".$Search_Item."%";
                             
                        $query14 = "SELECT * FROM search WHERE Symptoms LIKE '".$Search_Item."' ";
                        $query_run14 = mysqli_query($connection, $query14);

                        if(mysqli_num_rows($query_run14) > 0)        
                        {
                            while($row14 = mysqli_fetch_assoc($query_run14))
                            {
                                $x=$row14['Search_ID'];
                                if(!isset($GLOBALS[$x]) ){
                                   $GLOBALS[$x]=$x;
?>
<tr>
  					                <td><img  src=../images/<?php echo $row14['P_Image']; ?> width="145" height="135"></td>
                            <td><?php echo $row14['P_Name']; ?></td>
                            <td><?php echo $row14['P_Gender']; ?></td>
                            <td><?php echo $row14['Symptoms']; ?></td>
                            <td><?php echo $row14['Diagnosis']; ?></td>
                            <td><?php echo $row14['MP']; ?></td>
                            <td><?php echo $row14['Date']; ?></td>
                            <td><?php echo $row14['Enter_Time']; ?></td>
                            <td><?php echo $row14['Exit_Time']; ?></td>
                            <td><?php echo $row14['P_DOB']; ?></td>
                            <td><?php echo $row14['P_Phone']; ?></td>
                            <td><?php echo $row14['P_Email']; ?></td>
  					</tr>
  					<?php

                                 }}}}
                                   if(isset($_POST['Search_btn'])){
                            $Search_Item = $_POST['Search_Item'];
                             $Search_Item = "%".$Search_Item."%";
                             
                        $query15 = "SELECT * FROM search WHERE Diagnosis LIKE '".$Search_Item."' ";
                        $query_run15 = mysqli_query($connection, $query15);

                        if(mysqli_num_rows($query_run15) > 0)        
                        {
                            while($row15 = mysqli_fetch_assoc($query_run15))
                            {
                                $x=$row15['Search_ID'];
                                if(!isset($GLOBALS[$x]) ){
                                   $GLOBALS[$x]=$x;
?>
<tr>
  					                <td><img  src=../images/<?php echo $row15['P_Image']; ?> width="145" height="135"></td>
                            <td><?php echo $row15['P_Name']; ?></td>
                            <td><?php echo $row15['P_Gender']; ?></td>
                            <td><?php echo $row15['Symptoms']; ?></td>
                            <td><?php echo $row15['Diagnosis']; ?></td>
                            <td><?php echo $row15['MP']; ?></td>
                            <td><?php echo $row15['Date']; ?></td>
                            <td><?php echo $row15['Enter_Time']; ?></td>
                            <td><?php echo $row15['Exit_Time']; ?></td>
                            <td><?php echo $row15['P_DOB']; ?></td>
                            <td><?php echo $row15['P_Phone']; ?></td>
                            <td><?php echo $row15['P_Email']; ?></td>
  					</tr>
  					<?php

                                 }}}}
                                   if(isset($_POST['Search_btn'])){
                            $Search_Item = $_POST['Search_Item'];
                             $Search_Item = "%".$Search_Item."%";
                             
                        $query16 = "SELECT * FROM search WHERE MP LIKE '".$Search_Item."' ";
                        $query_run16 = mysqli_query($connection, $query16);

                        if(mysqli_num_rows($query_run16) > 0)        
                        {
                            while($row16 = mysqli_fetch_assoc($query_run16))
                            {
                                $x=$row16['Search_ID'];
                                if(!isset($GLOBALS[$x]) ){
                                   $GLOBALS[$x]=$x;
?>
<tr>
  					                <td><img  src=../images/<?php echo $row16['P_Image']; ?> width="145" height="135"></td>
                            <td><?php echo $row16['P_Name']; ?></td>
                            <td><?php echo $row16['P_Gender']; ?></td>
                            <td><?php echo $row16['Symptoms']; ?></td>
                            <td><?php echo $row16['Diagnosis']; ?></td>
                            <td><?php echo $row16['MP']; ?></td>
                            <td><?php echo $row16['Date']; ?></td>
                            <td><?php echo $row16['Enter_Time']; ?></td>
                            <td><?php echo $row16['Exit_Time']; ?></td>
                            <td><?php echo $row16['P_DOB']; ?></td>
                            <td><?php echo $row16['P_Phone']; ?></td>
                            <td><?php echo $row16['P_Email']; ?></td>
  					</tr>
  					<?php

                                 }}}}
                                   if(isset($_POST['Search_btn'])){
                            $Search_Item = $_POST['Search_Item'];
                             $Search_Item = "%".$Search_Item."%";
                             
                        $query17 = "SELECT * FROM search WHERE Date LIKE '".$Search_Item."' ";
                        $query_run17 = mysqli_query($connection, $query17);

                        if(mysqli_num_rows($query_run17) > 0)        
                        {
                            while($row17 = mysqli_fetch_assoc($query_run17))
                            {
                                $x=$row17['Search_ID'];
                                if(!isset($GLOBALS[$x]) ){
                                   $GLOBALS[$x]=$x;
?>
<tr>
  					                <td><img  src=../images/<?php echo $row17['P_Image']; ?> width="145" height="135"></td>
                            <td><?php echo $row17['P_Name']; ?></td>
                            <td><?php echo $row17['P_Gender']; ?></td>
                            <td><?php echo $row17['Symptoms']; ?></td>
                            <td><?php echo $row17['Diagnosis']; ?></td>
                            <td><?php echo $row17['MP']; ?></td>
                            <td><?php echo $row17['Date']; ?></td>
                            <td><?php echo $row17['Enter_Time']; ?></td>
                            <td><?php echo $row17['Exit_Time']; ?></td>
                            <td><?php echo $row17['P_DOB']; ?></td>
                            <td><?php echo $row17['P_Phone']; ?></td>
                            <td><?php echo $row17['P_Email']; ?></td>
  					</tr>
  					<?php

                                 }}}}

  			// if(mysqli_num_rows($query_run) > 0)        
  			// {
  			// 	while($row = mysqli_fetch_assoc($query_run))
  			// 	{
  			// 		$Patient_ID = $row['Patient_ID'];

  			// 		  	$query1 = "SELECT * FROM patient WHERE Patient_ID=$Patient_ID";
  	  //           $query_run1 = mysqli_query($connection, $query1);
  	  //           $row1 = mysqli_fetch_assoc($query_run1)

                                    $query18 = "SELECT * FROM search ";
                        $query_run18 = mysqli_query($connection, $query18);

                        if(mysqli_num_rows($query_run18) > 0)        
                        {
                            while($row18 = mysqli_fetch_assoc($query_run18))
                            {
                                 $x=$row18['Search_ID'];
                                if(!isset($GLOBALS[$x]) ){
                                   $GLOBALS[$x]=$x;
  					?>
  					<tr>
  					               <td><img  src=../images/<?php echo $row18['P_Image']; ?> width="145" height="135"></td>
                            <td><?php echo $row18['P_Name']; ?></td>
                            <td><?php echo $row18['P_Gender']; ?></td>
                            <td><?php echo $row18['Symptoms']; ?></td>
                            <td><?php echo $row18['Diagnosis']; ?></td>
                            <td><?php echo $row18['MP']; ?></td>
                            <td><?php echo $row18['Date']; ?></td>
                            <td><?php echo $row18['Enter_Time']; ?></td>
                            <td><?php echo $row18['Exit_Time']; ?></td>
                            <td><?php echo $row18['P_DOB']; ?></td>
                            <td><?php echo $row18['P_Phone']; ?></td>
                            <td><?php echo $row18['P_Email']; ?></td>
  					</tr>
  					<?php
  				} 
  			}
        }
  			else {
  				echo "No Record Found";
  			}
  			?>
  		</tbody>
  	</table>

  </div>
</div>
</div>
</div>
<!-- /.container-fluid -->


<?php 
include('includes/scripts.php'); 
include('includes/footer.php'); 
?>