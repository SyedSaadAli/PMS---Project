<?php
include('security.php');
include('CheckLogin.php');
include('includes/header.php'); 
include('includes/navbar.php'); 
?>



<head>
  <title>chart</title>
  <script src="https://code.highcharts.com/highcharts.js"></script>
  <script src="https://code.highcharts.com/modules/exporting.js"></script>
  <script src="https://code.highcharts.com/modules/export-data.js"></script>
  <script src="https://code.highcharts.com/modules/accessibility.js"></script>

  <style>

    <div class="container-fluid">

    <!-- Datatables Example -->
    <div class="card shadow mb-4">

    <div class="card-header py-3">
    <form action="#" method="">
    <h6 class="n-0 font-weight-bold text-primary">


    </form>

    </h6> </div>
    </div>
    </div>
    .highcharts-figure, .highcharts-data-table table {
      min-width: 320px; 
      max-width: 800px;
      margin: 1em auto;
    }

    .highcharts-data-table table {
     font-family: Verdana, sans-serif;
     border-collapse: collapse;
     border: 1px solid #EBEBEB;
     margin: 10px auto;
     text-align: center;
     width: 100%;
     max-width: 500px;
   }
   .highcharts-data-table caption {
    padding: 1em 0;
    font-size: 1.2em;
    color: #555;
  }
  .highcharts-data-table th {
   font-weight: 600;
   padding: 0.5em;
 }
 .highcharts-data-table td, .highcharts-data-table th, .highcharts-data-table caption {
  padding: 0.5em;
}
.highcharts-data-table thead tr, .highcharts-data-table tr:nth-child(even) {
  background: #f8f8f8;
}
.highcharts-data-table tr:hover {
  background: #f1f7ff;
}


input[type="number"] {
	min-width: 50px;
}

</style>
</head>

<body>
  <div class="container-fluid">

    <!-- Datatables Example -->
    <div class="card shadow mb-4">

      <div class="card-header py-3">
       
          <h6 class="n-0 font-weight-bold text-primary">

           <form action="chart.php" method="post">
            <input type="date" name="Start_Date" value="" >
            <input type="date" name="End_Date" value="">
            <button type="submit" name="generate" class="btn btn-primary" style="float: right;">Generate Sales Graph</button>
          </form>

    

      </h6> </div>
    </div>
  </div>


  <?php 
  $res = 0;
  $query = "SELECT * FROM product1";
  $query_run = mysqli_query($connection, $query);
  if(mysqli_num_rows($query_run) > 0){
    while($row = mysqli_fetch_assoc($query_run)){
      $x = $row['Buying_Price'];
      $res += $x;
    }
  }
  $res2 = 0;
  $query2 = "SELECT * FROM product";
  $query_run2 = mysqli_query($connection, $query2);
  if(mysqli_num_rows($query_run2) > 0){
    while($row2 = mysqli_fetch_assoc($query_run2)){
      $x2 = $row2['Selling_Price'];
      $res2 += $x2;
    }
  }
  ?>



  <figure class="highcharts-figure">
    <div id="container"></div>

  </figure>
  <script>

    Highcharts.chart('container', {
      chart: {
        plotBackgroundColor: null,
        plotBorderWidth: null,
        plotShadow: false,
        type: 'pie'
      },
      title: {
        text: 'Sales Graph'
      },
      tooltip: {
        pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
      },
      accessibility: {
        point: {
          valueSuffix: 'AED'
        }
      },
      plotOptions: {
        pie: {
          allowPointSelect: true,
          cursor: 'pointer',
          dataLabels: {
            enabled: true,
            format: '<b>{point.name}</b>: {point.y:.1f} AED'
          }
        }
      },
      series: [{
        name: 'Price',
        colorByPoint: true,
        data: [{
          name: 'Sales',
          y: <?php echo $res2; ?>
        }, {
          name: 'Purchased',
          y: <?php echo $res; ?>
        }]
      }]
    });

  </script>

  <?php 
  if(isset($_POST['generate']))
  {

    $start = $_POST['Start_Date'];
    $end = $_POST['End_Date'];


    $res3 = 0;
    $query3 = "SELECT * FROM product1";
    $query_run3 = mysqli_query($connection, $query3);
    if(mysqli_num_rows($query_run3) > 0){
      while($row3 = mysqli_fetch_assoc($query_run3)){
        if(($row3['Purchased_Date'] === $start  OR $row3['Purchased_Date'] > $start) AND ($row3['Purchased_Date'] === $end  OR $row3['Purchased_Date'] < $end)){
        $x3 = $row3['Buying_Price'];
        $res3 += $x3;

      }
    }
  }
    $res4 = 0;
    $query4 = "SELECT * FROM product";
    $query_run4 = mysqli_query($connection, $query4);
    if(mysqli_num_rows($query_run4) > 0){
      while($row4 = mysqli_fetch_assoc($query_run4)){
        if(($row4['Selling_Date'] === $start  OR $row4['Selling_Date'] > $start) AND ($row4['Selling_Date'] === $end  OR $row4['Selling_Date'] < $end)){
        $x4 = $row4['Selling_Price'];
        $res4 += $x4;
      
      }
    }
  }

    ?>
    <figure class="highcharts-figure">
      <div id="container2"></div>

    </figure>
    <script>

      Highcharts.chart('container2', {
        chart: {
          plotBackgroundColor: null,
          plotBorderWidth: null,
          plotShadow: false,
          type: 'pie'
        },
        title: {
          text: 'Sales Graph'
        },
        tooltip: {
          pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
        },
        accessibility: {
          point: {
            valueSuffix: 'AED'
          }
        },
        plotOptions: {
          pie: {
            allowPointSelect: true,
            cursor: 'pointer',
            dataLabels: {
              enabled: true,
              format: '<b>{point.name}</b>: {point.y:.1f} AED'
            }
          }
        },
        series: [{
          name: 'Price',
          colorByPoint: true,
          data: [{
            name: 'Sales',
            y: <?php echo $res4; ?>
          }, {
            name: 'Purchased',
            y: <?php echo $res3; ?>
          }]
        }]
      });

    </script>
  <?php } ?>
</body>

